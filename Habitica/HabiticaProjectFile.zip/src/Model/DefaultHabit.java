package Model;

public abstract class DefaultHabit extends Habit {
    public DefaultHabit(String name, String description) {
        super(name, description);
    }   

}

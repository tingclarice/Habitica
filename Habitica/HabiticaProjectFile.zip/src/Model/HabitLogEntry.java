package Model;

public class HabitLogEntry {
    private String habitName;
    private boolean goalMet;
    private String details; // optional, e.g., "Calories: 1800/2000"

    public HabitLogEntry(String habitName, boolean goalMet, String details) {
        this.habitName = habitName;
        this.goalMet = goalMet;
        this.details = details;
    }

    public String getHabitName() {
        return habitName;
    }

    public boolean isGoalMet() {
        return goalMet;
    }

    public String getDetails() {
        return details;
    }
}

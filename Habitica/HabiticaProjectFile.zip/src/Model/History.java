package Model;

import java.util.ArrayList;
import java.util.List;

public class History {
    private String date;
    private List<HabitLogEntry> habitLogs;

    public History(String date) {
        this.date = date;
        this.habitLogs = new ArrayList<>();
    }

    public String getDate() {
        return date;
    }

    public void addHabitLog(HabitLogEntry entry) {
        habitLogs.add(entry);
    }

    public List<HabitLogEntry> getHabitLogs() {
        return habitLogs;
    }

    // You can add a method to check if all goals met that day
    public boolean allGoalsMet() {
        for (HabitLogEntry entry : habitLogs) {
            if (!entry.isGoalMet()) {
                return false;
            }
        }
        return true;
    }
}
